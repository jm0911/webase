var wbtn = document.getElementById('white_btn');
  wbtn.addEventListener('click',function(){
  document.getElementById('target').className='white';
})

var bbtn = document.getElementById('black_btn');
  bbtn.addEventListener('click',function(){
  document.getElementById('target').className='black';
})
