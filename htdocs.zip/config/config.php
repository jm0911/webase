<?php
  $config =array(
    "host"=>"localhost",
    "duser"=>"root",
    "dpw"=>"160916",
    "dname"=>"opentutorials"
  );
 ?>
