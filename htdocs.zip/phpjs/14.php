<?php
	$conn = mysqli_connect('localhost','root', '160916');
	mysqli_select_db($conn, 'opentutorials');
  $name= mysqli_real_escape_string($conn,$_GET['name']);
  $password=mysqli_real_escape_string($conn,$_GET['password']);
  $sql = "SELECT * FROM passw WHERE name = '".$name."' AND password ='".$password."'";
	$result = mysqli_query($conn, $sql);
  echo $sql;
  var_dump($result);
 ?>

<!DOCTYPE html>
<html>
<head>
 <meta charset = utf-8 />

</head>
<body>
  <?php

    if($result->num_rows=='0'){
      echo "뉘시지";
    }
    else if($result->num_rows=='1'){
      echo "안녕하세여";
    }
   ?>
</body>
</html>
