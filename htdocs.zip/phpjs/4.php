<!DOCTYPE html>
<html>
<head>
 <meta charset = utf-8 />

</head>
<body>
  <script>
    name = "egoing";
    document.write("안녕하세요"+name);
  </script>
  <h1>php</h1>
 <?php
  $name="egoing";
  echo "안녕하세요".$name;
  ?>
</body>
</html>
