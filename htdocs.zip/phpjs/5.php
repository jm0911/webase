<!DOCTYPE html>
<html>
<head>
 <meta charset = utf-8 />

</head>
<body>
  <h1>JavaScreqipt</h1>
  <script type="text/javascript">
    document.write(1==1);
  </script>

  <h1>php</h1>
  <?php
    echo 1==1;

    var_dump(1==1);
   ?>
</body>
</html>
