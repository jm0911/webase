<!DOCTYPE html>
<html>
<head>
 <meta charset = utf-8 />

</head>
<body>


  <script type="text/javascript">
    password = prompt("비밀번호");
    if(password == 1111){
      document.write("welcome");
    }
    else {
      document.write("who are u");
    }
  </script>
  <?php

   ?>


</body>
</html>
