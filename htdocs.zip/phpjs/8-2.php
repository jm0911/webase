<!DOCTYPE html>
<html>
<head>
 <meta charset = utf-8 />

</head>
<body>
  <?php
    $result = $_GET["password"];
    if($result== "1111"){
      echo "주인님 하이";
    }
    else{
      echo "뉘신지";
    }
   ?>
</body>
</html>
