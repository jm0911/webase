<!DOCTYPE html>
<html>
<head>
 <meta charset = utf-8 />

</head>
<body>
  <h1>JavaScreqipt</h1>
  <script type="text/javascript">
    if(true){
      document.write("참");
    }
  </script>

  <h1>php</h1>
  <?php
    $result=(1==1);
    if($result){
      echo "참";
    }
   ?>
</body>
</html>
