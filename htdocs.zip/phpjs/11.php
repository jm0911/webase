<!DOCTYPE html>
<html>
<head>
 <meta charset = utf-8 />

</head>
<body>
  <ul>
    <script>
    list = new Array("z","x","c");
    i=0;
    while(i<list.length){
      document.write("<li>"+list[i]+"</li>");
      document.write(i);
      i += 1;
    }
    </script>
  </ul>

  <ul>
    <?php
      $list = array("준맹","봉박","준현");
      $i=0;
      while($i<count($list)){
        echo "<li>".$list[$i]."</li>";
        echo $i;
        $i += 1;
      }
     ?>
  </ul>


</body>
</html>
