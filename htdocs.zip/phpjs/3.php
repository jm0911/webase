<!DOCTYPE html>
<html>
<head>
 <meta charset = utf-8 />

</head>
<body>
  <script type="text/javascript">
    document.write("hello world");
  </script>

  <?php
  >
</body>
</html>
