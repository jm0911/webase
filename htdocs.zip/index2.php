


<!DOCTYPE html>
<html>
<head>
	<meta charset = utf-8 />
	<link rel="stylesheet" type="text/css" href="http://localhost/style.css">
</head>
<body id="target">
	<header>
		<img src="https://s3.ap-northeast-2.amazonaws.com/opentutorials-user-file/course/94.png" />
		<h1><a href="http://localhost/index2.php">JavaScript</a></h1>
	</header>

	<nav>
		<ol>
			<?php
				echo file_get_contents("list.txt");
			 ?>
		</ol>
	</nav>
	<div id ="z">
		<input type="button" value="white" id="white_btn">
		<input type="button" value="black" id="black_btn">
	</div>

	<article class="">
		<?php
		if(empty($_GET['id']==false)){
			echo file_get_contents($_GET['id'].".txt");
		}

		?>
	</article>
</body>
<script src="http://localhost/script.js"></script>
</html>
