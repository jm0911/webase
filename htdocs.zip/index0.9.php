<?php
require("config/config.php");
require("lib/db.php");
$conn = db_init($config["host"],$config["duser"],$config["dpw"],$config["dname"]);
$result = mysqli_query($conn, 'SELECT * FROM creat');
?>



<!DOCTYPE html>
<html>
	<head>
		<meta charset = utf-8 />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
		<link rel="stylesheet" type="text/css" href="/style.0.9.css">
	</head>
	<body id="target">
		<div class="container">
			<header class="bg-light text-center" >
				<img src="https://s3.ap-northeast-2.amazonaws.com/opentutorials-user-file/course/94.png" class="rounded" id="logo" />
				<h1><a href="/index0.9.php">JavaScript</a></h1>
			</header>



			<div class="row">
				<div class="col-md-3">
					<nav class="nav flex-sm-column">
						<ol>
							<?php
								while($row = mysqli_fetch_assoc($result)){
									echo '<li><a class="nav-link" href="/index0.9.php?id='.$row['id'].'">'.htmlspecialchars($row["title"]).'</a></li>';
									// echo "<br />";
								}

							 ?>
						</ol>
					</nav>
				</div>

				<div class="col-md-9">
					<div class="float-end" id="z">
						<div class="btn-group" role="group" aria-label="Basic outlined example">
							<input type="button" value="white" id="white_btn" class="btn btn-outline-primary">
							<input type="button" value="black" id="black_btn" class="btn btn-outline-primary">
						</div>
						<a href = "/write0.9.php" class="btn btn-success">쓰기</a>
					</div>

					<br>
					<hr>

					<article class="" id="art">
						<?php
						if(empty($_GET['id'])===false){
							$sql = "SELECT * FROM creat WHERE id =".$_GET['id'];
							//echo $sql;
							$result = mysqli_query($conn, $sql);

							$row = mysqli_fetch_assoc($result);

							echo '<h2>'.htmlspecialchars($row['title']).'</h2>';
							echo '<h6>'.htmlspecialchars($row['author']).'</h6>';
							echo strip_tags($row['description'],'<a><h1><h2><h3><ul><ol><li><img>');
						}


						?>
					</article>
				</div>

			</div>
		</div>



		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
	</body>
<script src="/script.js"></script>
</html>
