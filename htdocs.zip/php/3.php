<?php
  echo $_POST['title'];
  echo "<br />";
  echo $_POST['description'];
 ?>
