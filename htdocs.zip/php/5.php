<!DOCTYPE html>
<html>
<head>
 <meta charset = utf-8 />

</head>
<body>
  <?php
    echo htmlspecialchars('<a href="http://opentutorials.org/course/1">codingeverybody</a>');
   ?>

</body>
</html>
