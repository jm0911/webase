<?php
require("config/config.php");
require("lib/db.php");
$conn = db_init($config["host"],$config["duser"],$config["dpw"],$config["dname"]);
$result = mysqli_query($conn, 'SELECT * FROM creat');
?>



<!DOCTYPE html>
<html>
  <head>
  	<meta charset = utf-8 />
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  	<link rel="stylesheet" type="text/css" href="/style.0.9.css">
  </head>

  <body id="target">

  	<div class="container">
  		<header class="bg-light text-center" >
  			<img src="https://s3.ap-northeast-2.amazonaws.com/opentutorials-user-file/course/94.png" class="rounded" id="logo" />
  			<h1><a href="/index0.9.php">JavaScript</a></h1>
  		</header>

  		<div class="row">
  			<div class="col-md-3">
  				<nav class="nav flex-sm-column">
  					<ol>
  						<?php
  							while($row = mysqli_fetch_assoc($result)){
  								echo '<li><a class="nav-link" href="/index0.9.php?id='.$row['id'].'">'.htmlspecialchars($row["title"]).'</a></li>';
  								// echo "<br />";
  							}

  						 ?>
  					</ol>
  				</nav>
  			</div>

  			<div class="col-md-9">
  				<div class="float-end" id="z">
  					<div class="btn-group" role="group" aria-label="Basic outlined example">
  						<input type="button" value="white" id="white_btn" class="btn btn-outline-primary">
  						<input type="button" value="black" id="black_btn" class="btn btn-outline-primary">
  					</div>
  					<a href = "/write0.9.php" class="btn btn-success">쓰기</a>
  				</div>

  				<br>
  				<hr>

  				<article class="">
            <form action= "process.php" method="POST">

              <div class="mb-3">
                <label for="form-title" class="form-label">제목</label>
                <input type="text" class="form-control" name="title" id="form-title" aria-describedby="emailHelp">
              </div>

              <div class="mb-3">
                <label for="form-author" class="form-label">작성자</label>
                <input type="text" class="form-control" name="author" id="form-author">
              </div>

              <div class="mb-3">
                <label for="description" class="form-label">본문</label>
                <textarea class="form-control" name="description" id="description" rows="8" cols="80"></textarea>
              </div>

              <p>
        				<input type="hidden" role="uploadcare-uploader" name="my_file" />
                <input type="submit" name="제출" class="btn btn-outline-primary">
              </p>
            </form>
  				</article>
  			</div>

  		</div>
  	</div>

    <script>
    	UPLOADCARE_PUBLIC_KEY = 'e659f2247d8c7099f246';
  	</script>
  	<script src="https://ucarecdn.com/libs/widget/3.x/uploadcare.full.min.js" charset="utf-8"></script>

  	<script>
  		var singleWidget = uploadcare.SingleWidget('[role=uploadcare-uploader]');
  		singleWidget.onUploadComplete(function(info){
  			document.getElementById('description').value = document.getElementById('description').value + '<img src="'+info.cdnUrl+'">';
  		});
  	</script>

  	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
  </body>
    <script src="/script.js"></script>
</html>
